package assignment_1.task_1;

public class Task1A {


    public void bubbleSort(int[] array) {
        if (isOneElement(array)) {
            for (int i = array.length - 1; i >= 0; i--) {
                boolean flag = true;
                for (int j = 0; j < i; j++) {
                    if (array[j] > array[j + 1]) {
                        int swap = array[j];
                        array[j] = array[j + 1];
                        array[j + 1] = swap;
                        flag = false;
                    }
                }
                if (flag) {
                    break;
                }
            }
        }

    }

    public void insertionSort(int[] array) {
        if(isOneElement(array)){
            for (int i = 1; i < array.length; i++) {
                int j = i;
                boolean flag = true;
                while (j > 0 && array[j] < array[j - 1]) {
                    int swap = array[j];
                    array[j] = array[j - 1];
                    array[j - 1] = swap;
                    j--;
                    flag = false;
                }
                if (flag) {
                    break;
                }
            }
        }
    }

    public void mergeSort(int[] array) {
        if (isOneElement(array)){
            class Sorter {
                void sort(int[] arr, int low, int high) {
                    if (low < high) {
                        int mid = low + (high - low) / 2;
                        sort(arr, low, mid);
                        sort(arr, mid + 1, high);
                        merge(arr, low, mid, high);
                    }
                }

                void merge(int[] arr, int low, int mid, int high) {
                    int[] temp = new int[high - low + 1];
                    int i = low, j = mid + 1, k = 0;

                    while (i <= mid && j <= high) {
                        temp[k++] = (arr[i] <= arr[j]) ? arr[i++] : arr[j++];
                    }

                    while (i <= mid) temp[k++] = arr[i++];

                    while (j <= high) temp[k++] = arr[j++];

                    System.arraycopy(temp, 0, arr, low, temp.length);
                }
            }

            new Sorter().sort(array, 0, array.length - 1);
        }


    }
    public void quickSort(int[] array) {
        if (isOneElement(array)){
            class Sorter {
                void sort(int[] arr, int low, int high) {
                    if (low < high) {
                        int pivotIndex = partition(arr, low, high);
                        sort(arr, low, pivotIndex - 1);
                        sort(arr, pivotIndex + 1, high);
                    }
                }


                int partition(int[] arr, int low, int high) {
                    int pivot = arr[high];
                    int i = low - 1;

                    for (int j = low; j < high; j++) {
                        if (arr[j] <= pivot) {
                            i++;
                            int temp = arr[i];
                            arr[i] = arr[j];
                            arr[j] = temp;
                        }
                    }

                    int temp = arr[i + 1];
                    arr[i + 1] = arr[high];
                    arr[high] = temp;

                    return i + 1;
                }
            }
            var sorter = new Sorter();
            sorter.sort(array, 0, array.length - 1);
        }
    }
    private boolean isOneElement(int[] array) {
        return array != null && array.length > 1;
    }
}
