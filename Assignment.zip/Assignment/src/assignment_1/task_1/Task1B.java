package assignment_1.task_1;


public class Task1B {

    // Update MergeSort to handle CardRecord objects
    public void mergeSort(CardRecord[] array) {
        if (array == null || array.length <= 1) return;
        CardRecord[] helper = new CardRecord[array.length];
        mergeSortRec(array, helper, 0, array.length - 1);
    }

    private void mergeSortRec(CardRecord[] array, CardRecord[] helper, int low, int high) {
        if (low < high) {
            int mid = low + (high - low) / 2;
            mergeSortRec(array, helper, low, mid);
            mergeSortRec(array, helper, mid + 1, high);
            merge(array, helper, low, mid, high);
        }
    }

    private void merge(CardRecord[] array, CardRecord[] helper, int low, int mid, int high) {
        for (int i = low; i <= high; i++) helper[i] = array[i];

        int i = low, j = mid + 1, k = low;
        while (i <= mid && j <= high) {
            // Sort by PIN
            if (helper[i].pin <= helper[j].pin) {
                array[k] = helper[i];
                i++;
            } else {
                array[k] = helper[j];
                j++;
            }
            k++;
        }
        while (i <= mid) {
            array[k] = helper[i];
            k++;
            i++;
        }
    }

    // Update RadixSort to handle CardRecord objects using PIN as the key
    public void radixSort(CardRecord[] array) {
        if (array == null || array.length <= 1) return;

        // Find the maximum PIN to know number of digits
        int max = 0;
        for (CardRecord r : array) {
            if (r.pin > max) max = r.pin;
        }

        for (int exp = 1; max / exp > 0; exp *= 10) {
            CardRecord[] output = new CardRecord[array.length];
            int[] count = new int[10];

            for (CardRecord record : array) {
                count[(record.pin / exp) % 10]++;
            }
            for (int i = 1; i < 10; i++) {
                count[i] += count[i - 1];
            }
            for (int i = array.length - 1; i >= 0; i--) {
                output[count[(array[i].pin / exp) % 10] - 1] = array[i];
                count[(array[i].pin / exp) % 10]--;
            }
            System.arraycopy(output, 0, array, 0, array.length);
        }
    }
}