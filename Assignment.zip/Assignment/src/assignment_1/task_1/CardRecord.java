package assignment_1.task_1;

public class CardRecord {

    String cardFront, cardBack, expiry, network;
    int pin;

    public CardRecord(String front, String back, String exp, int pin, String net) {
        this.cardFront = front;
        this.cardBack = back;
        this.expiry = exp;
        this.pin = pin;
        this.network = net;
    }

    public int getSortableDate() {
        String[] parts = expiry.split("/");
        return Integer.parseInt(parts[1] + parts[0]);
    }
}
