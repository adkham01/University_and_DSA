package assignment_1.task_2;

import java.io.Serializable;
import java.util.RandomAccess;


public class MyVector<E> implements RandomAccess, Serializable {
    @java.io.Serial
    private static final long serialVersionUID = 1L;

    public int[] data;
    private int size;
    private int capacity;

    public MyVector() {
        this.capacity = 10;
        this.data = new int[capacity];
        this.size = 0;
    }

    public int get(int index){
        if(index < 0 || index >= size) throw new IndexOutOfBoundsException();
        return data[index];
    }

    public void set(int index, int value){
        if(size < 0 || index >= size) throw new IndexOutOfBoundsException();
        data[index] = value;
    }

    public void append(int value){
        if(size == capacity) resize(capacity * 2);
        data[size++] = value;
    }

    public void resize(int newCapacity){
        int[] newData = new int[newCapacity];
        int limit = Math.min(size, capacity);
        System.arraycopy(data, 0, newData, 0, limit);
        data = newData;
        capacity = newCapacity;
        if(size > capacity) size = capacity;
    }

    public void remove(int index){
        if(index < 0 || index >= size) throw new IndexOutOfBoundsException();
        for(int i = index; i < size - 1; i++) data[i] = data[i + 1];
        size--;
    }

    public void removeSegment(int fromIndex, int toIndex){
        if(fromIndex < 0 || toIndex > size || fromIndex > toIndex) throw new IndexOutOfBoundsException();

        int numToRemove = toIndex - fromIndex;
        if (numToRemove == 0) return;

        int numToShift = size - toIndex;
        if (numToShift > 0) {
            System.arraycopy(data, toIndex, data, fromIndex, numToShift);
        }

        size -= numToRemove;
    }
}
