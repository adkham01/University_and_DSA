package assignment_2.task_3;

public class MyTernary {
    private static class Node {
        int key1, key2;
        boolean hasTwoKeys = false;
        Node left, mid, right;
        Node(int key) { this.key1 = key; }
    }

    private Node root;

    public void insert(int key) {
        root = insert(root, key);
    }

    private Node insert(Node node, int key) {
        if (node == null) return new Node(key);

        if (!node.hasTwoKeys) {
            if (key < node.key1) {
                node.key2 = node.key1;
                node.key1 = key;
            } else if (key > node.key1) {
                node.key2 = key;
            }
            node.hasTwoKeys = true;
        } else {
            if (key < node.key1) node.left = insert(node.left, key);
            else if (key > node.key2) node.right = insert(node.right, key);
            else node.mid = insert(node.mid, key);
        }
        return node;
    }

    public int getHeight() { return getHeight(root); }

    private int getHeight(Node node) {
        if (node == null) return -1;
        return 1 + Math.max(getHeight(node.left), Math.max(getHeight(node.mid), getHeight(node.right)));
    }
}
