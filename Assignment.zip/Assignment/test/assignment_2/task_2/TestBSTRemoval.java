package assignment_2.task_2;

import assignment_2.task_3.MyBST;

import java.util.Random;
import java.util.TreeSet;

public class TestBSTRemoval {
    static void main() {
        int n = 10000; // Dataset size
        Random rand = new Random();


        int[] keys = rand.ints(0, 100000).distinct().limit(n).toArray();

        MyBST customTree = new MyBST();
        TreeSet<Integer> libraryTree = new TreeSet<>();

        for (int k : keys) {
            customTree.insert(k);
            libraryTree.add(k);
        }

        IO.println("=".repeat(50));
        IO.println(String.format(" REMOVAL BENCHMARK (N = %d)", n));
        IO.println("=".repeat(50));


        int[] removalOrder = keys.clone();
        shuffle(removalOrder);

        long startCustom = System.nanoTime();
        for (int k : removalOrder) {
            customTree.delete(k);
        }
        long endCustom = System.nanoTime();

        long startLibrary = System.nanoTime();
        for (int k : removalOrder) {
            libraryTree.remove(k);
        }
        long endLibrary = System.nanoTime();

        IO.println(String.format("%-25s | %-15s", "Structure", "Time (ns)"));
        IO.println("-".repeat(50));
        IO.println(String.format("%-25s | %-15d", "Custom MyBST Delete", (endCustom - startCustom)));
        IO.println(String.format("%-25s | %-15d", "Java TreeSet Remove", (endLibrary - startLibrary)));
        IO.println("=".repeat(50));
    }

    private static void shuffle(int[] array) {
        Random rnd = new Random();
        for (int i = array.length - 1; i > 0; i--) {
            int index = rnd.nextInt(i + 1);
            int a = array[index];
            array[index] = array[i];
            array[i] = a;
        }
    }
}
