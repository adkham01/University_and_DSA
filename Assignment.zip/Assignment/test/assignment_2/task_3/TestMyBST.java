package assignment_2.task_3;

import java.util.*;

public class TestMyBST {
    public static void main(String[] args) {
        Random rand = new Random();
        int m = 14;
        int n = (int) Math.pow(2, m) - 1;

        int[] keys = rand.ints(0, 1000000).distinct().limit(n).toArray();

        IO.println("=".repeat(65));
        IO.println(String.format(" TREE EXPERIMENT (N = %d)", n));
        IO.println("=".repeat(65));
        IO.println(String.format("%-25s | %-15s | %-10s", "Scenario", "Time (ns)", "Height"));
        IO.println("-".repeat(65));

        MyBST treeA = new MyBST();
        long startA = System.nanoTime();
        for (int k : keys) treeA.insert(k);
        long endA = System.nanoTime();
        IO.println(String.format("%-25s | %-15d | %-10d", "a) BST Random", (endA - startA), treeA.getHeight()));

        int[] sortedKeys = keys.clone();
        Arrays.sort(sortedKeys);
        List<Integer> bestBST = new ArrayList<>();
        generateBestOrder(sortedKeys, 0, sortedKeys.length - 1, bestBST);

        MyBST treeB = new MyBST();
        long startB = System.nanoTime();
        for (int k : bestBST) treeB.insert(k);
        long endB = System.nanoTime();
        IO.println(String.format("%-25s | %-15d | %-10d", "b) BST Best-Case", (endB - startB), treeB.getHeight()));

        TreeSet<Integer> librarySet = new TreeSet<>();
        long startC = System.nanoTime();
        for (int k : keys) librarySet.add(k);
        long endC = System.nanoTime();
        IO.println(String.format("%-25s | %-15d | %-10s", "c) TreeSet", (endC - startC), "N/A"));

        MyTernary treeD = new MyTernary();
        long startD = System.nanoTime();
        for (int k : keys) treeD.insert(k);
        long endD = System.nanoTime();
        IO.println(String.format("%-25s | %-15d | %-10d", "d) Ternary Random", (endD - startD), treeD.getHeight()));

        List<Integer> bestTernary = new ArrayList<>();
        generateTernaryBestOrder(sortedKeys, 0, sortedKeys.length - 1, bestTernary);
        MyTernary treeE = new MyTernary();
        long startE = System.nanoTime();
        for (int k : bestTernary) treeE.insert(k);
        long endE = System.nanoTime();
        IO.println(String.format("%-25s | %-15d | %-10d", "e) Ternary Best-Case", (endE - startE), treeE.getHeight()));

        MyAVL treeF = new MyAVL();
        long startF = System.nanoTime();
        for (int k : keys) treeF.insert(k);
        long endF = System.nanoTime();
        IO.println(String.format("%-25s | %-15d | %-10d", "f) AVL Self-Balance", (endF - startF), treeF.getHeight()));

        IO.println("=".repeat(65));
    }

    private static void generateBestOrder(int[] sorted, int left, int right, List<Integer> result) {
        if (left > right) return;
        int mid = left + (right - left) / 2;
        result.add(sorted[mid]);
        generateBestOrder(sorted, left, mid - 1, result);
        generateBestOrder(sorted, mid + 1, right, result);
    }

    private static void generateTernaryBestOrder(int[] sorted, int left, int right, List<Integer> result) {
        if (left > right) return;
        int n = right - left + 1;
        int m1 = left + n / 3;
        int m2 = left + 2 * n / 3;
        result.add(sorted[m1]);
        if (m1 != m2) result.add(sorted[m2]);
        generateTernaryBestOrder(sorted, left, m1 - 1, result);
        generateTernaryBestOrder(sorted, m1 + 1, m2 - 1, result);
        generateTernaryBestOrder(sorted, m2 + 1, right, result);
    }
}