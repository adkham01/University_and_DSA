package assignment_2.task_1;

import assignment_2.task_3.MyBST;

import java.util.*;

public class TestMyBST {
    static void main() {
        Random rand = new Random();
        int m = 14; // n = 2^14 - 1 = 16383
        int n = (int) Math.pow(2, m) - 1;

        int[] keys = rand.ints(0, 1000000).distinct().limit(n).toArray();

        IO.println("=".repeat(50));
        IO.println(String.format(" BST EXPERIMENT (N = %d)", n));
        IO.println("=".repeat(50));
        IO.println(String.format("%-25s | %-15s | %-10s", "Scenario", "Time (ns)", "Height"));
        IO.println("-".repeat(50));

        MyBST treeA = new MyBST();
        long startA = System.nanoTime();
        for (int k : keys) treeA.insert(k);
        long endA = System.nanoTime();
        IO.println(String.format("%-25s | %-15d | %-10d", "a) Random Order", (endA - startA), treeA.getHeight()));

        int[] sortedKeys = keys.clone();
        Arrays.sort(sortedKeys);
        List<Integer> bestOrderList = new ArrayList<>();
        generateBestOrder(sortedKeys, 0, sortedKeys.length - 1, bestOrderList);

        MyBST treeB = new MyBST();
        long startB = System.nanoTime();
        for (int k : bestOrderList) treeB.insert(k);
        long endB = System.nanoTime();
        IO.println(String.format("%-25s | %-15d | %-10d", "b) Best-Case (Balanced)", (endB - startB), treeB.getHeight()));

        TreeSet<Integer> librarySet = new TreeSet<>();
        long startC = System.nanoTime();
        for (int k : keys) librarySet.add(k);
        long endC = System.nanoTime();
        IO.println(String.format("%-25s | %-15d | %-10s", "c) Java TreeSet", (endC - startC), "N/A"));

        IO.println("=".repeat(50));
    }

    private static void generateBestOrder(int[] sorted, int left, int right, List<Integer> result) {
        if (left > right) return;

        int mid = left + (right - left) / 2;
        result.add(sorted[mid]);

        generateBestOrder(sorted, left, mid - 1, result);
        generateBestOrder(sorted, mid + 1, right, result);
    }
}
