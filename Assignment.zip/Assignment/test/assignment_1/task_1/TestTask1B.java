package assignment_1.task_1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.*;

public class TestTask1B {
    static void main() {
        Task1B algorithms = new Task1B();

        try {
            List<CardRecord> baseRecords = loadAndMatch();

            IO.println("=".repeat(50));
            IO.println(String.format("%-10s | %-15s | %-15s", "Size (N)", "MergeSort (ns)", "RadixSort (ns)"));
            IO.println("-".repeat(50));

            int[] sizes = {50, 1000, 5000, 10000, 20000, 50000};

            for (int n : sizes) {
                CardRecord[] testData = scaleData(baseRecords, n);

                shuffle(testData);

                CardRecord[] mergeCopy = testData.clone();
                long startMerge = System.nanoTime();
                algorithms.mergeSort(mergeCopy);
                long endMerge = System.nanoTime();

                CardRecord[] radixCopy = testData.clone();
                long startRadix = System.nanoTime();
                algorithms.radixSort(radixCopy);
                long endRadix = System.nanoTime();

                IO.println(String.format("%-10d | %-15d | %-15d",
                        n, (endMerge - startMerge), (endRadix - startRadix)));
            }
            IO.println("=".repeat(50));
            String filename = "data/sorted_records.csv";
            saveToCSV(baseRecords.toArray(new CardRecord[0]), filename);

        } catch (Exception e) {
            IO.println("Error loading files: " + e.getMessage());
        }
    }

    private static List<CardRecord> loadAndMatch() throws Exception {
        List<CardRecord> records = new ArrayList<>();
        try (BufferedReader brA = new BufferedReader(new FileReader("data/carddump1.csv"));
             BufferedReader brB = new BufferedReader(new FileReader("data/carddump2.csv"))) {

            brA.readLine(); // Skip headers
            brB.readLine();

            String lineA, lineB;
            while ((lineA = brA.readLine()) != null && (lineB = brB.readLine()) != null) {
                String[] pA = lineA.split(",");
                String[] pB = lineB.split(",");
                records.add(new CardRecord(pA[0], pB[0], pB[1], Integer.parseInt(pB[3]), pB[4]));
            }
        }
        return records;
    }

    private static CardRecord[] scaleData(List<CardRecord> base, int targetSize) {
        CardRecord[] scaled = new CardRecord[targetSize];
        for (int i = 0; i < targetSize; i++) {
            scaled[i] = base.get(i % base.size()); // Reuse the 50 records to fill larger arrays
        }
        return scaled;
    }

    private static void shuffle(CardRecord[] array) {
        Random rand = new Random();
        for (int i = array.length - 1; i > 0; i--) {
            int j = rand.nextInt(i + 1);
            CardRecord temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }
    private static void saveToCSV(CardRecord[] records, String fileName) {
        try (PrintWriter writer = new PrintWriter((fileName))) {
            writer.println("Credit Card Number,Expiry Date,PIN,Issuing Network");


            for (CardRecord r : records) {
                writer.printf("%s,%s,%d,%s%n",
                        r.cardFront.replace("****", "") + r.cardBack.substring(12),
                        r.expiry,
                        r.pin,
                        r.network
                );
            }
            IO.println("Successfully saved sorted records to: " + fileName);
        } catch (Exception e) {
            IO.println("Error saving CSV: " + e.getMessage());
        }
    }
}