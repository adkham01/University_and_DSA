package assignment_1.task_1;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;
import java.util.stream.IntStream;

public class TestTask1A {
    static void main() {
        var scanner = new Scanner(System.in);

        System.out.print("How many times do you want to run the benchmark? ");
        int times = scanner.nextInt();

        IO.println("\n" + "=".repeat(55));
        System.out.printf(" STARTING BENCHMARK SESSION (%d runs)%n", times);
        IO.println("=".repeat(55));

        for (int i = 1; i <= times; i++) {
            // Formats "RUN 1 OF 5" with padding
            System.out.printf("[ RUN %d OF %d ]%n", i, times);

            benchmarking();

            if (i < times) {
                IO.println("-".repeat(50)); // Divider between runs
            }
        }

        IO.println("=".repeat(55));
        IO.println(" SESSION COMPLETE");
        IO.println("=".repeat(55));
    }

    static void benchmarking() {
        var rand = new Random();
        var soring = new Task1A();

        int small = rand.nextInt(50) + 1;
        int large = rand.nextInt(10000) + 1;

        int[] smallArray = IntStream.generate(() -> rand.nextInt(50) + 1).limit(small).toArray();
        int[] largeArray = IntStream.generate(() -> rand.nextInt(1000) + 100).limit(large).toArray();

        System.out.printf("%-15s | %-15s | %-15s%n", "Algorithm", "Small (" + small + ") ns", "Large (" + large + ") ms");
        IO.println("-".repeat(50));

        // --- Bubble Sort ---
        long startSmall = System.nanoTime();
        soring.bubbleSort(smallArray.clone());
        long endSmall = System.nanoTime();

        long startLarge = System.currentTimeMillis();
        soring.bubbleSort(largeArray.clone());
        long endLarge = System.currentTimeMillis();
        printRow("Bubble Sort", (endSmall - startSmall), (endLarge - startLarge));

        // --- Insertion Sort ---
        startSmall = System.nanoTime();
        soring.insertionSort(smallArray.clone());
        endSmall = System.nanoTime();

        startLarge = System.currentTimeMillis();
        soring.insertionSort(largeArray.clone());
        endLarge = System.currentTimeMillis();
        printRow("Insertion Sort", (endSmall - startSmall), (endLarge - startLarge));

        // --- Merge Sort ---
        startSmall = System.nanoTime();
        soring.mergeSort(smallArray.clone());
        endSmall = System.nanoTime();

        startLarge = System.currentTimeMillis();
        soring.mergeSort(largeArray.clone());
        endLarge = System.currentTimeMillis();
        printRow("Merge Sort", (endSmall - startSmall), (endLarge - startLarge));

        // --- Quick Sort ---
        startSmall = System.nanoTime();
        soring.quickSort(smallArray.clone());
        endSmall = System.nanoTime();

        startLarge = System.currentTimeMillis();
        soring.quickSort(largeArray.clone());
        endLarge = System.currentTimeMillis();
        printRow("Quick Sort", (endSmall - startSmall), (endLarge - startLarge));

        writeArrayToCSV(smallArray, "data/sorted_small.csv");
        writeArrayToCSV(largeArray, "data/sorted_large.csv");
    }

    private static void printRow(String name, long smallTime, long largeTime) {
        System.out.printf("%-15s | %-15d | %-15d%n", name, smallTime, largeTime);
    }
    public static void writeArrayToCSV(int[] array, String filename) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename, true))) {
            for (int i = 0; i < array.length; i++) {
                writer.print(array[i]);
                if (i < array.length - 1) {
                    writer.print(",");
                }
            }
            writer.println();
            IO.println("Array saved to " + filename);
        } catch (IOException e) {
            IO.println("Error writing to file: " + e.getMessage());
        }
    }
}