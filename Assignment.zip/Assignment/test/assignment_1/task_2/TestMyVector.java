package assignment_1.task_2;

import java.util.LinkedList;
import java.util.Vector;

public class TestMyVector {
    public static void main(String[] args) {
        int iterations = 10000000;

        IO.println("=".repeat(70));
        System.out.printf(" STARTING DYNAMIC ARRAY TEST (%d elements)%n", iterations);
        IO.println("=".repeat(70));


        var myVec = new MyVector();
        long startMy = System.currentTimeMillis();
        for (int i = 0; i < iterations; i++) {
            myVec.append(i);
        }
        long endMy = System.currentTimeMillis();
        printResult("MyVector (Custom)", (endMy - startMy), iterations);

        var javaVec = new Vector<>();
        long startJava = System.currentTimeMillis();
        for (int i = 0; i < iterations; i++) {
            javaVec.add(i);
        }
        long endJava = System.currentTimeMillis();
        printResult("Java Vector", (endJava - startJava), iterations);

        var linkedList = new LinkedList<>();
        long startLinked = System.currentTimeMillis();
        for (int i = 0; i < iterations; i++) {
            linkedList.add(i);
        }
        long endLinked = System.currentTimeMillis();
        printResult("Linked List", (endLinked - startLinked), iterations);

        IO.println("=".repeat(70));

        IO.println("\n--- Testing Segment Deletion (Middle 10k elements) ---");
        long delStart = System.currentTimeMillis();
        myVec.removeSegment(500000, 510000);
        long delEnd = System.currentTimeMillis();
        System.out.printf("MyVector removal time: %d ms%n", (delEnd - delStart));
    }

    private static void printResult(String name, long time, int count) {
        System.out.printf("%-20s | Time: %6d ms | Amortized: %.6f ms/%n",
                name, time, (double)time / count);
    }
}